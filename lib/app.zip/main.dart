import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'core/database/isar_service.dart';
import 'core/locale/locale_service.dart';
import 'core/database/sync_manager.dart';
// Isar schemas — import generated .g.dart files
import 'features/auth/models/user_session.dart';
import 'features/orders/models/fsm_order.dart';
import 'features/route_map/models/route_stop.dart';
import 'features/stock/models/product.dart';
import 'features/stock/models/stock_move.dart';
import 'features/timesheet/models/timesheet_entry.dart';
import 'features/expense/models/expense.dart';
import 'features/work_order/models/work_report.dart';
import 'features/orders/services/orders_service.dart';
import 'features/timesheet/services/timesheet_service.dart';
import 'features/expense/services/expense_service.dart';
import 'features/stock/services/stock_service.dart';
import 'app/app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Khởi tạo locale/date formatting mặc định để tránh lỗi Intl.
  const defaultLocale = 'vi_VN';
  Intl.defaultLocale = defaultLocale;
  await initializeDateFormatting(defaultLocale, null);
  LocaleService.instance.setLocale(defaultLocale);

  // Chỉ cho phép xoay dọc (portrait) trên thiết bị di động
  if (!kIsWeb) {
    await SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);
  }

  // Tạm bỏ qua Khởi tạo Isar DB trên web (Isar 3.x không hỗ trợ web).
  // Chạy init IsarService.instance.init chỉ trên mobile/desktop.
  if (!kIsWeb) {
    try {
      await IsarService.instance.init([
        UserSessionSchema,
        FsmOrderSchema,
        RouteStopSchema,
        ProductSchema,
        StockMoveSchema,
        TimesheetEntrySchema,
        ExpenseSchema,
        WorkReportSchema,
      ]);
      // Đăng ký các sync handlers cho offline sync sau khi Isar khởi tạo thành công
      SyncManager.instance.registerSyncHandler(OrdersService.instance.syncPending);
      SyncManager.instance.registerSyncHandler(TimesheetService.instance.syncPending);
      SyncManager.instance.registerSyncHandler(ExpenseService.instance.syncPending);
      SyncManager.instance.registerSyncHandler(StockService.instance.syncPending);

      // Bắt đầu lắng nghe trạng thái mạng để tự động sync
      SyncManager.instance.startListening();
    } catch (e) {
      debugPrint('Init Isar Error: $e');
    }
  }

  runApp(const App());
}
